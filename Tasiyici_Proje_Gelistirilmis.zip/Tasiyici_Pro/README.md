# TAŞIYICI — Android uygulaması

Bu proje TAŞIYICI'nın Android/Kotlin başlangıç uygulamasıdır.

## İçerik
- Koyu lacivert, altın ve krem renkli arayüz
- Ana menü ve beş işlem bölümü
- Kayıt ekleme, listeleme, düzenleme ve silme
- Kayıtların cihazda kalıcı saklanması
- JSON yedeği dışa aktarma ve geri yükleme
- GitHub Actions ile debug APK üretimi

## APK
GitHub Actions tamamlandığında `tasiyici-debug-apk` adlı artifact içinden APK indirilebilir.

## Önemli kapsam notu
Bu sürüm, kullanılabilir kayıt ve yedekleme temelini sağlar. Kullanıcının çizimlerinde tarif ettiği tüm özel akışlar (aylık paket PDF'leri/WhatsApp, ayrıntılı iş ve ödeme durumları, avans ve eşit taksit planları, şifreli yedekleme, gelişmiş raporlar) henüz tamamlanmış sayılmaz; bunlar ayrıca geliştirilip cihazda test edilmelidir. Uygulamayı eksiksiz diye sunmayın.
