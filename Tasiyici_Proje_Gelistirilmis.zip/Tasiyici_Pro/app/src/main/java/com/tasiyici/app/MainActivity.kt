package com.tasiyici.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF101C2B)
private val Navy = Color(0xFF172A40)
private val Panel = Color(0xFF203A53)
private val Gold = Color(0xFFD9AD62)
private val Cream = Color(0xFFF5F0E7)
private val Muted = Color(0xFF9EACB9)
private val Green = Color(0xFF55B88A)
private val Red = Color(0xFFE27676)

data class Entry(val id: Long, val module: String, val date: String, val title: String, val amount: String, val currency: String, val details: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TasiyiciApp(this) }
    }
}

private fun readEntries(context: Context): MutableList<Entry> {
    val raw = context.getSharedPreferences("tasiyici", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
    val arr = JSONArray(raw)
    val list = mutableListOf<Entry>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        list.add(Entry(o.optLong("id"), o.optString("module"), o.optString("date"), o.optString("title"), o.optString("amount"), o.optString("currency"), o.optString("details")))
    }
    return list
}
private fun saveEntries(context: Context, entries: List<Entry>) {
    val arr = JSONArray()
    entries.forEach { e ->
        arr.put(JSONObject().put("id", e.id).put("module", e.module).put("date", e.date).put("title", e.title).put("amount", e.amount).put("currency", e.currency).put("details", e.details))
    }
    context.getSharedPreferences("tasiyici", Context.MODE_PRIVATE).edit().putString("entries", arr.toString()).apply()
}
private fun today() = SimpleDateFormat("dd.MM.yyyy", Locale("tr", "TR")).format(Date())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasiyiciApp(context: Context) {
    val modules = listOf("Alınan Ödemeler", "Yapılan İşler", "Masraflar", "Alınan Avans", "Taksitler")
    var entries by remember { mutableStateOf(readEntries(context)) }
    var page by remember { mutableStateOf("Ana Menü") }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var showBackupInfo by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(JSONArray().apply {
            entries.forEach { e -> put(JSONObject().put("id", e.id).put("module", e.module).put("date", e.date).put("title", e.title).put("amount", e.amount).put("currency", e.currency).put("details", e.details)) }
        }.toString().toByteArray()) }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val text = context.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
            val arr = JSONArray(text)
            val imported = mutableListOf<Entry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                imported.add(Entry(o.optLong("id"), o.optString("module"), o.optString("date"), o.optString("title"), o.optString("amount"), o.optString("currency"), o.optString("details")))
            }
            entries = imported; saveEntries(context, entries)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Green, background = Ink, surface = Navy,
        onPrimary = Ink, onSecondary = Ink, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(containerColor = Ink, topBar = {
            Column(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 22.dp, vertical = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Gold, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Route, null, tint = Ink, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("TAŞIYICI", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                        Text("İş ve tahsilat yönetimi", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.DirectionsCar, null, tint = Gold, modifier = Modifier.size(28.dp))
                }
            }
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (page == "Ana Menü") {
                    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(20.dp)) {
                                    Text("KONTROL PANELİ", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("İşlerin, tahsilatların\ntek yerde.", color = Cream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(15.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        StatPill("Kayıt", entries.size.toString())
                                        StatPill("Tahsilat", entries.filter { it.module == "Alınan Ödemeler" }.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }.toInt().toString() + " ₺")
                                    }
                                }
                            }
                        }
                        item { Text("İŞLEMLER", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp) }
                        items(modules) { module ->
                            val icon = when(module) {
                                "Alınan Ödemeler" -> Icons.Default.AccountBalanceWallet
                                "Yapılan İşler" -> Icons.Default.Work
                                "Masraflar" -> Icons.Default.ReceiptLong
                                "Alınan Avans" -> Icons.Default.Payments
                                else -> Icons.Default.CalendarMonth
                            }
                            Row(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(18.dp)).clickable { page = module }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).background(Panel, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Gold) }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(module, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                    Text("${entries.count { it.module == module }} kayıt", color = Muted, fontSize = 12.sp)
                                }
                                Icon(Icons.Default.ChevronRight, null, tint = Gold)
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(18.dp)).clickable { page = "Yedekleme" }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudUpload, null, tint = Gold)
                                Spacer(Modifier.width(14.dp))
                                Text("Yedekleme ve geri yükleme", color = Cream, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Gold)
                            }
                        }
                    }
                } else if (page == "Yedekleme") {
                    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        BackButton { page = "Ana Menü" }
                        Text("YEDEKLEME", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Kayıtlarını telefon dışında sakla. Yeni telefona geçerken yedek dosyanı geri yükleyebilirsin.", color = Muted)
                        Button(onClick = { exportLauncher.launch("tasiyici-yedek.json") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Yedeği dışa aktar") }
                        OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("Yedeği geri yükle") }
                        Text("Not: Yedek dosyasını Gmail, Drive veya başka güvenli bir yerde sakla. Uygulama içindeki kayıtlar tek başına telefon kaybına karşı yeterli değildir.", color = Muted, fontSize = 12.sp)
                    }
                } else {
                    val list = entries.filter { it.module == page }.sortedByDescending { it.id }
                    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                        Spacer(Modifier.height(5.dp))
                        BackButton { page = "Ana Menü" }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(page.uppercase(Locale("tr","TR")), color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Button(onClick = { editing = null; showForm = true }, colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Default.Add, null); Text("Yeni kayıt") }
                        }
                        Spacer(Modifier.height(14.dp))
                        if (list.isEmpty()) {
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(46.dp))
                                    Spacer(Modifier.height(10.dp))
                                    Text("Henüz kayıt yok", color = Cream, fontWeight = FontWeight.Bold)
                                    Text("Yeni kayıt ekleyerek başlayabilirsin.", color = Muted, fontSize = 13.sp)
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                                items(list, key = { it.id }) { e ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(15.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(e.title, color = Cream, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                                Text("${e.amount} ${e.currency}", color = Gold, fontWeight = FontWeight.Bold)
                                            }
                                            Text("${e.date}  •  ${e.details}", color = Muted, fontSize = 12.sp)
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                TextButton(onClick = { editing = e; showForm = true }) { Text("Düzenle") }
                                                TextButton(onClick = { entries = entries.filterNot { it.id == e.id }; saveEntries(context, entries) }, colors = ButtonDefaults.textButtonColors(contentColor = Red)) { Text("Sil") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        EntryDialog(page, editing, onDismiss = { showForm = false }, onSave = { e ->
            entries = if (editing == null) entries + e else entries.map { if (it.id == e.id) e else it }
            saveEntries(context, entries); showForm = false
        })
    }
}

@Composable
private fun StatPill(label: String, value: String) {
    Column(Modifier.background(Ink.copy(alpha = .45f), RoundedCornerShape(12.dp)).padding(horizontal = 13.dp, vertical = 9.dp)) {
        Text(label, color = Muted, fontSize = 10.sp)
        Text(value, color = Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}
@Composable
private fun BackButton(onClick: () -> Unit) {
    Text("‹  Ana menü", color = Gold, modifier = Modifier.clickable { onClick() }.padding(vertical = 12.dp), fontWeight = FontWeight.SemiBold)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EntryDialog(module: String, old: Entry?, onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var date by remember { mutableStateOf(old?.date ?: today()) }
    var title by remember { mutableStateOf(old?.title ?: "") }
    var amount by remember { mutableStateOf(old?.amount ?: "") }
    var currency by remember { mutableStateOf(old?.currency ?: "TL") }
    var details by remember { mutableStateOf(old?.details ?: "") }
    var error by remember { mutableStateOf(false) }
    val titleHint = when(module) {
        "Yapılan İşler" -> "Nereden – Nereye / iş detayı"
        "Masraflar" -> "Masraf türü (Yakıt, Ceza, Yemek...)"
        "Alınan Avans" -> "Avansın açıklaması"
        "Taksitler" -> "Borç / taksit açıklaması"
        else -> "İş detayı"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Navy,
        title = { Text(if (old == null) "Yeni kayıt" else "Kaydı düzenle", color = Gold, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(date, { date = it }, label = { Text("Tarih (gg.aa.yyyy)") }, singleLine = true)
                OutlinedTextField(title, { title = it }, label = { Text(titleHint) }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text(if (module == "Taksitler") "Ödenen / tutar" else "Tutar") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("TL", "EUR", "USD").forEach { c ->
                        FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) })
                    }
                }
                OutlinedTextField(details, { details = it }, label = { Text("Açıklama / telefon / not") }, minLines = 2)
                if (error) Text("Lütfen iş detayı ve geçerli tutar gir.", color = Red, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val parsed = amount.replace(",", ".").toDoubleOrNull()
                if (title.isBlank() || parsed == null || parsed < 0) error = true
                else onSave(Entry(old?.id ?: System.currentTimeMillis(), module, date.ifBlank { today() }, title.trim(), parsed.toString(), currency, details.trim()))
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Kaydet", color = Ink) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç", color = Muted) } }
    )
}
