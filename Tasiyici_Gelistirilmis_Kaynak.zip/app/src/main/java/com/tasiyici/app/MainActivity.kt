package com.tasiyici.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private data class Row(
    val id: Long, val section: String, val date: String, val title: String, val detail: String,
    val amount: Double, val currency: String, val phone: String, val method: String,
    val source: String, val status: String, val total: Double = 0.0,
    val paid: Double = 0.0, val parts: Int = 0, val paidParts: Int = 0
)

private class DB(ctx: Context) {
    private val pref = ctx.getSharedPreferences("tasiyici_store", Context.MODE_PRIVATE)
    fun read(): MutableList<Row> {
        val a = JSONArray(pref.getString("rows", "[]"))
        val out = mutableListOf<Row>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out += Row(o.optLong("id"),o.optString("section"),o.optString("date"),o.optString("title"),
                o.optString("detail"),o.optDouble("amount"),o.optString("currency","TL"),o.optString("phone"),
                o.optString("method"),o.optString("source"),o.optString("status"),o.optDouble("total"),
                o.optDouble("paid"),o.optInt("parts"),o.optInt("paidParts"))
        }
        return out
    }
    fun write(rows: List<Row>) {
        val a = JSONArray()
        rows.forEach { r ->
            val o=JSONObject()
            o.put("id",r.id); o.put("section",r.section); o.put("date",r.date); o.put("title",r.title)
            o.put("detail",r.detail); o.put("amount",r.amount); o.put("currency",r.currency)
            o.put("phone",r.phone); o.put("method",r.method); o.put("source",r.source); o.put("status",r.status)
            o.put("total",r.total); o.put("paid",r.paid); o.put("parts",r.parts); o.put("paidParts",r.paidParts)
            a.put(o)
        }
        pref.edit().putString("rows",a.toString()).apply()
    }
}

class MainActivity : Activity() {
    private lateinit var db: DB
    private lateinit var page: LinearLayout
    private val navy=Color.rgb(15,31,53)
    private val gold=Color.rgb(190,151,76)
    private val sections=listOf("Alınan Ödemeler","Yapılan İşler","Masraflar","Alınan Avans","Taksit")
    private val createBackup=501
    private val restoreBackup=502
    private val createPdf=503
    private var backupText=""
    private var pdfPending: PdfDocument?=null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=DB(this); home() }

    private fun shell(title:String) {
        page=LinearLayout(this).apply { orientation=1; setPadding(16,14,16,22); setBackgroundColor(Color.rgb(245,247,250)) }
        val scroll=ScrollView(this); scroll.addView(page); setContentView(scroll)
        page.addView(TextView(this).apply {
            text="TAŞIYICI   •   $title"; textSize=20f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD
            setPadding(18,22,18,22); setBackgroundColor(navy)
        })
    }
    private fun label(s:String,size:Float=14f,bold:Boolean=false) {
        page.addView(TextView(this).apply { text=s; textSize=size; setTextColor(navy); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(4,9,4,7) })
    }
    private fun action(s:String, fn:()->Unit) {
        page.addView(Button(this).apply {
            text=s; isAllCaps=false; textSize=15f; setTextColor(Color.WHITE)
            backgroundTintList=android.content.res.ColorStateList.valueOf(navy)
            setOnClickListener { fn() }
        }, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,5,0,5) })
    }
    private fun home() {
        shell("Ana Sayfa")
        label("İş, ödeme ve masraflarını tek yerden takip et.",16f,true)
        label("Kayıtların cihazında saklanır. İnternet gerekmez.",12f)
        sections.forEach { s -> action(s) { list(s) } }
        action("Aylık Raporlar") { reports() }
        action("Yedek Al / Geri Yükle") { backupDialog() }
        label("Zuhruf: 13",12f)
    }
    private fun list(section:String) {
        shell(section)
        action("+ Yeni Kayıt") { form(section,null) }
        if(section=="Alınan Ödemeler") {
            action("Bugünü Paketle / PDF Paylaş") { pdfFor(db.read().filter { it.section==section && it.date==today() }) }
            action("Bu Haftayı Paketle / PDF Paylaş") { pdfFor(db.read().filter { it.section==section && inWeek(it.date) }) }
            action("Bu Ayı Paketle / PDF Paylaş") { pdfFor(db.read().filter { it.section==section && monthKey(it.date)==monthKey(today()) }) }
            action("Özel Dönem Seç") { dateRangeDialog(section) }
        }
        val rows=db.read().filter { it.section==section }.sortedByDescending { parseDate(it.date) }
        if(rows.isEmpty()) label("Henüz kayıt yok.")
        rows.groupBy { monthKey(it.date) }.toSortedMap(compareByDescending { it }).forEach { (m, items) ->
            label("▰  $m",17f,true)
            items.forEach { r ->
                val card=LinearLayout(this).apply { orientation=1; setPadding(12,8,12,8); setBackgroundColor(Color.WHITE) }
                card.addView(TextView(this).apply { text="${r.date}  |  ${r.title}"; textSize=15f; setTextColor(navy); typeface=Typeface.DEFAULT_BOLD })
                card.addView(TextView(this).apply {
                    text="${r.detail}\n${fmt(r.amount,r.currency)}  •  ${r.status}\n${if(r.phone.isNotBlank()) "Tel: ${r.phone}" else ""}"
                    textSize=13f; setTextColor(Color.DKGRAY)
                })
                if(section=="Taksit") card.addView(TextView(this).apply {
                    text="Toplam: ${fmt(r.total,r.currency)}   Ödenen: ${fmt(r.paid,r.currency)}   Kalan: ${fmt((r.total-r.paid).coerceAtLeast(0.0),r.currency)}\nTaksit: ${r.paidParts}/${r.parts} ödendi"
                    setTextColor(navy); textSize=13f
                })
                val line=LinearLayout(this).apply { orientation=0 }
                line.addView(Button(this).apply { text="Düzenle"; isAllCaps=false; setOnClickListener { form(section,r) } },LinearLayout.LayoutParams(0,-2,1f))
                line.addView(Button(this).apply { text="Sil"; isAllCaps=false; setOnClickListener { delete(r) } },LinearLayout.LayoutParams(0,-2,1f))
                card.addView(line)
                page.addView(card,LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,4,0,8) })
            }
        }
        action("Ana Sayfa") { home() }
    }

    private fun form(section:String, old:Row?) {
        val box=LinearLayout(this).apply { orientation=1; setPadding(12,4,12,4) }
        val sc=ScrollView(this); sc.addView(box)
        val inputs=linkedMapOf<String,EditText>()
        fun field(key:String, value:String="", hint:String="") {
            box.addView(TextView(this).apply { text=key; textSize=13f; setTextColor(navy); setPadding(2,8,2,2) })
            val e=EditText(this).apply { setSingleLine(true); setText(value); if(hint.isNotEmpty()) this.hint=hint }
            box.addView(e); inputs[key]=e
        }
        field("Tarih",old?.date ?: today(),"GG.AA.YYYY")
        when(section) {
            "Yapılan İşler" -> { field("Nereden – Nereye",old?.title ?: ""); field("İş açıklaması",old?.detail ?: ""); field("Bütçe",old?.amount?.toString() ?: ""); field("Para birimi (TL / Euro / Dolar)",old?.currency ?: "TL"); field("İş sahibinin telefon numarası",old?.phone ?: ""); field("Ödeme durumu (Alındı / Bekleniyor)",old?.status ?: "Bekleniyor") }
            "Masraflar" -> { field("Masraf türü (Yakıt / Ceza / Yemek / Tamir / Diğer)",old?.title ?: ""); field("Diğer açıklaması / Not",old?.detail ?: ""); field("Tutar",old?.amount?.toString() ?: ""); field("Para birimi",old?.currency ?: "TL") }
            "Alınan Avans" -> { field("Açıklama / Nereden alındı",old?.title ?: ""); field("Tutar",old?.amount?.toString() ?: ""); field("Para birimi",old?.currency ?: "TL"); field("Alınan yer (Müşteriden / Otelden / Diğer)",old?.source ?: "Müşteriden"); field("Yöntem (EFT / Nakit / Diğer)",old?.method ?: "Nakit") }
            "Alınan Ödemeler" -> { field("İş detayı",old?.title ?: ""); field("Alınan ödeme",old?.amount?.toString() ?: ""); field("Para birimi (TL / Euro / Dolar)",old?.currency ?: "TL"); field("Ödeme yöntemi (EFT / Elden-Nakit / Diğer)",old?.method ?: ""); field("Kimden (Müşteriden / Otelden / Diğer)",old?.source ?: ""); field("Diğer açıklama",old?.detail ?: ""); field("Telefon numarası",old?.phone ?: "") }
            "Taksit" -> { field("Borç / Taksit adı",old?.title ?: ""); field("Toplam borç",old?.total?.takeIf { it>0 }?.toString() ?: ""); field("Toplam taksit sayısı",old?.parts?.takeIf { it>0 }?.toString() ?: ""); field("Bu ödemede yatırılan tutar", ""); field("Para birimi",old?.currency ?: "TL"); field("Telefon / Not",old?.phone ?: "") }
        }
        AlertDialog.Builder(this).setTitle(if(old==null) "$section • Yeni Kayıt" else "$section • Düzenle").setView(sc)
            .setNegativeButton("Vazgeç",null).setPositiveButton("Kaydet") { _,_ ->
                fun v(k:String)=inputs[k]?.text?.toString()?.trim().orEmpty()
                fun num(k:String)=v(k).replace(",",".").toDoubleOrNull() ?: 0.0
                val amountKey=when(section) { "Yapılan İşler"->"Bütçe"; "Alınan Ödemeler"->"Alınan ödeme"; "Taksit"->"Bu ödemede yatırılan tutar"; else->"Tutar" }
                var total=old?.total ?: 0.0; var paid=old?.paid ?: 0.0; var parts=old?.parts ?: 0; var paidParts=old?.paidParts ?: 0
                if(section=="Taksit") {
                    total=num("Toplam borç"); parts=v("Toplam taksit sayısı").toIntOrNull() ?: 0
                    paid=(old?.paid ?: 0.0)+num(amountKey)
                    val per=if(parts>0) total/parts else 0.0
                    paidParts=if(per>0) (paid/per).toInt().coerceAtMost(parts) else 0
                }
                val titleKey=when(section) { "Yapılan İşler"->"Nereden – Nereye"; "Masraflar"->"Masraf türü (Yakıt / Ceza / Yemek / Tamir / Diğer)"; "Alınan Avans"->"Açıklama / Nereden alındı"; "Alınan Ödemeler"->"İş detayı"; else->"Borç / Taksit adı" }
                val detailKey=when(section) { "Yapılan İşler"->"İş açıklaması"; "Masraflar"->"Diğer açıklaması / Not"; "Alınan Ödemeler"->"Diğer açıklama"; else->"" }
                val phoneKey=when(section) { "Yapılan İşler"->"İş sahibinin telefon numarası"; "Alınan Ödemeler"->"Telefon numarası"; "Taksit"->"Telefon / Not"; else->"" }
                val status=if(section=="Yapılan İşler") v("Ödeme durumu (Alındı / Bekleniyor)").ifBlank { "Bekleniyor" } else old?.status ?: "Alındı"
                val row=Row(old?.id ?: System.currentTimeMillis(),section,v("Tarih").ifBlank { today() },v(titleKey),
                    if(detailKey.isNotBlank()) v(detailKey) else "",num(amountKey),
                    v("Para birimi (TL / Euro / Dolar)").ifBlank { v("Para birimi").ifBlank { "TL" } },
                    if(phoneKey.isNotBlank()) v(phoneKey) else "",
                    v("Ödeme yöntemi (EFT / Elden-Nakit / Diğer)").ifBlank { v("Yöntem (EFT / Nakit / Diğer)") },
                    v("Kimden (Müşteriden / Otelden / Diğer)").ifBlank { v("Alınan yer (Müşteriden / Otelden / Diğer)") },
                    status,total,paid,parts,paidParts)
                val all=db.read(); if(old!=null) all.removeAll { it.id==old.id }; all.add(row); db.write(all); list(section)
            }.show()
    }

    private fun delete(r:Row) {
        AlertDialog.Builder(this).setMessage("Bu kaydı silmek istiyor musun?")
            .setNegativeButton("Vazgeç",null).setPositiveButton("Sil") { _,_ -> db.write(db.read().filterNot { it.id==r.id }); list(r.section) }.show()
    }

    private fun reports() {
        shell("Aylık Rapor")
        val all=db.read()
        val months=all.map { monthKey(it.date) }.distinct().sortedDescending()
        if(months.isEmpty()) label("Henüz kayıt bulunmuyor.")
        months.forEach { m ->
            val jobs=all.filter { it.section=="Yapılan İşler" && monthKey(it.date)==m }
            val paid=jobs.filter { it.status.contains("Alındı",true) }.sumOf { it.amount }
            val waiting=jobs.filter { it.status.contains("Bek",true) }.sumOf { it.amount }
            val expenses=all.filter { it.section=="Masraflar" && monthKey(it.date)==m }.sumOf { it.amount }
            val income=all.filter { it.section=="Alınan Ödemeler" && monthKey(it.date)==m }.sumOf { it.amount }
            label("$m",17f,true)
            label("İş sayısı: ${jobs.size}\nİşlerden alınan: ${fmt(paid,"TL")}\nBekleyen: ${fmt(waiting,"TL")}\nAlınan ödemeler: ${fmt(income,"TL")}\nMasraflar: ${fmt(expenses,"TL")}")
            action("$m PDF raporu") { pdfFor(all.filter { monthKey(it.date)==m }) }
        }
        action("Ana Sayfa") { home() }
    }

    private fun backupDialog() {
        AlertDialog.Builder(this).setTitle("Yedekleme")
            .setMessage("Yedek Al: kayıtları JSON dosyasına aktarır. Geri Yükle: seçtiğin JSON yedeğini bu telefona yükler.")
            .setPositiveButton("Yedek Al") { _,_ -> saveBackup() }
            .setNeutralButton("Geri Yükle") { _,_ -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE),restoreBackup) }
            .setNegativeButton("Kapat",null).show()
    }
    private fun saveBackup() {
        val a=JSONArray()
        db.read().forEach { r ->
            val o=JSONObject()
            o.put("id",r.id); o.put("section",r.section); o.put("date",r.date); o.put("title",r.title); o.put("detail",r.detail)
            o.put("amount",r.amount); o.put("currency",r.currency); o.put("phone",r.phone); o.put("method",r.method)
            o.put("source",r.source); o.put("status",r.status); o.put("total",r.total); o.put("paid",r.paid)
            o.put("parts",r.parts); o.put("paidParts",r.paidParts); a.put(o)
        }
        backupText=a.toString()
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").putExtra(Intent.EXTRA_TITLE,"tasiyici_yedek.json"),createBackup)
    }
    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(res!=RESULT_OK || data?.data==null) return
        val uri=data.data!!
        try {
            when(req) {
                createBackup -> contentResolver.openOutputStream(uri)?.use { it.write(backupText.toByteArray(Charsets.UTF_8)) }
                restoreBackup -> {
                    val raw=contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val a=JSONArray(raw); val rows=mutableListOf<Row>()
                    for(i in 0 until a.length()) {
                        val o=a.getJSONObject(i)
                        rows += Row(o.optLong("id",System.currentTimeMillis()+i),o.optString("section"),o.optString("date"),
                            o.optString("title"),o.optString("detail"),o.optDouble("amount"),o.optString("currency","TL"),
                            o.optString("phone"),o.optString("method"),o.optString("source"),o.optString("status"),
                            o.optDouble("total"),o.optDouble("paid"),o.optInt("parts"),o.optInt("paidParts"))
                    }
                    db.write(rows); home(); Toast.makeText(this,"Yedek geri yüklendi.",Toast.LENGTH_LONG).show()
                }
                createPdf -> { contentResolver.openOutputStream(uri)?.use { pdfPending?.writeTo(it) }; pdfPending?.close(); pdfPending=null }
            }
        } catch(e:Exception) { Toast.makeText(this,"Dosya hatası: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    private fun pdfFor(rows:List<Row>) {
        try {
            val doc=PdfDocument(); val title=android.graphics.Paint().apply { color=navy; textSize=17f; typeface=Typeface.DEFAULT_BOLD }
            val body=android.graphics.Paint().apply { color=Color.DKGRAY; textSize=10.5f }
            var n=1; var y=55
            var p=doc.startPage(PdfDocument.PageInfo.Builder(595,842,n).create())
            p.canvas.drawText("TASIYICI • RAPOR",32f,32f,title)
            rows.forEach { r ->
                if(y>790) { doc.finishPage(p); n++; y=50; p=doc.startPage(PdfDocument.PageInfo.Builder(595,842,n).create()) }
                p.canvas.drawText("${r.date} | ${r.section} | ${r.title}",32f,y.toFloat(),body); y+=17
                p.canvas.drawText("${r.detail} | ${fmt(r.amount,r.currency)} | ${r.status} | ${r.phone}",42f,y.toFloat(),body); y+=23
            }
            doc.finishPage(p); pdfPending=doc
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/pdf").putExtra(Intent.EXTRA_TITLE,"tasiyici_rapor.pdf"),createPdf)
        } catch(e:Exception) { Toast.makeText(this,"PDF oluşturulamadı: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun dateRangeDialog(section:String) {
        val from=EditText(this).apply { hint="Başlangıç GG.AA.YYYY" }
        val to=EditText(this).apply { hint="Bitiş GG.AA.YYYY" }
        val box=LinearLayout(this).apply { orientation=1; setPadding(18,4,18,4); addView(from); addView(to) }
        AlertDialog.Builder(this).setTitle("Özel dönem").setView(box).setNegativeButton("Vazgeç",null)
            .setPositiveButton("PDF hazırla") { _,_ ->
                val a=parseDate(from.text.toString()); val b=parseDate(to.text.toString())
                pdfFor(db.read().filter { it.section==section && parseDate(it.date)>=a && parseDate(it.date)<=b })
            }.show()
    }

    private fun today()=SimpleDateFormat("dd.MM.yyyy",Locale("tr")).format(Date())
    private fun parseDate(s:String):Date=try { SimpleDateFormat("dd.MM.yyyy",Locale("tr")).parse(s) ?: Date(0) } catch(_:Exception) { Date(0) }
    private fun monthKey(s:String)=try { val d=parseDate(s); SimpleDateFormat("yyyy.MM",Locale.US).format(d) } catch(_:Exception) { "Bilinmiyor" }
    private fun inWeek(s:String):Boolean {
        val cal=Calendar.getInstance(); cal.firstDayOfWeek=Calendar.MONDAY
        val now=Calendar.getInstance(); val start=now.clone() as Calendar
        start.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY); start.set(Calendar.HOUR_OF_DAY,0); start.set(Calendar.MINUTE,0); start.set(Calendar.SECOND,0)
        val end=start.clone() as Calendar; end.add(Calendar.DAY_OF_MONTH,7)
        val d=Calendar.getInstance(); d.time=parseDate(s)
        return !d.before(start) && d.before(end)
    }
    private fun fmt(v:Double,c:String)=String.format(Locale("tr","TR"),"%.2f %s",v,c)
}
