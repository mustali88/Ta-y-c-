# TAŞIYICI
Android offline iş/ödeme/masraf/avans/taksit takip uygulaması.

- Yerel kalıcı kayıt
- Beş ana bölüm ve düzenleme/silme
- Dönemsel raporlar
- JSON yedek dışa/içe aktarma
- PDF rapor dışa aktarma
- GitHub Actions ile debug APK derleme

Not: Bu kaynak, Android CI üzerinde derlenip gerçek cihazda test edilmeden üretim için doğrulanmış sayılmaz. JSON yedek dosyası şifrelenmez.
